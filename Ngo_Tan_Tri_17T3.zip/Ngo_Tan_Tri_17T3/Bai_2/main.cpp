#include <bits/stdc++.h>
#include <math.h>
using namespace std;
int n,m,i,j;
double denta,x[1000][1000],y[1000],w[1000];
double Sigmoi(double s)
{
    return 1.0/(1.0+exp(-s));
}
double FUNCT(int a)
{
    double res=0;
    for(int i=1; i<=n; i++)
        res+=x[a][i]*w[i];
    return Sigmoi(res);
}
/*
2 3
1 1 0
1 0 1
0 1 1
*/
int main()
{
    freopen("INPUT.txt","r",stdin);
    cin>>n>>m;
    for(int i=1; i<=m; i++)
    {
        for(int j=1; j<=n; j++)
            cin>>x[i][j];
        cin>>y[i];
    }
    for(int i=1; i<=m; i++)
    {
        for(int j=1; j<=n; j++)
            cout<<x[i][j]<<" ";
        cout<<y[i];
        cout<<endl;
    }
    bool kt=false;
    double learingrate=0.01;
    while(1)
    {
        double denta=0;
        for(int i=1; i<=m; i++)
        {
            denta+=(FUNCT(i)-y[i]); //h(x)-y
            for (int j=1; j<=n; j++)
                w[j]-=denta*x[i][j]*learingrate/m; //cong thuc cap nhat
            if (abs(denta)<0.1)
                kt=true;
        }
        if (kt==true)
            break;
    }
    // in ra khi x1=0 x2=0
    cout<<"Cau b: Ket qua sau khi huan luyen la: "<<endl;
    for(int j=1; j<=n; j++)
        cout<<"w["<<j<<"]= "<<w[j]<<" "<<endl; // ket qua sau khi huan luyen
    x[3][1]=0;
    x[3][2]=0;
    cout<<"Cau C: ket qua cua ham sau khi cho x1=0 va x2=0:"<<endl;
    if (FUNCT(3)>=0.5)
        cout<<"Y=1"<<endl;
    else
        cout<<"Y=0"<<endl;
    return 0;
}
