#include<bits/stdc++.h>
using namespace std;
#define ll long long
vector<pair<ll,ll> > chuadien;
ll dem=0;
struct State{
  ll a[3][3];
  void print(){
    for(ll i=0;i<3;i++){
        for(ll j=0;j<3;j++){
             if(a[i][j]==0) cout<<"_";
      else if(a[i][j]==1) cout<<"o";
      else cout<<"x";
        }
        cout<<'\n';
    }
  }
};
queue<State> q;
int main(){
  State start;
  start.a[0][0]=1;
  start.a[0][1]=0;
  start.a[0][2]=0;
  start.a[1][0]=2;
  start.a[1][1]=2;
  start.a[1][2]=1;
  start.a[2][0]=0;
  start.a[2][1]=1;
  start.a[2][2]=0;
  chuadien.push_back({0,1});
  chuadien.push_back({0,2});
  chuadien.push_back({2,0});
  chuadien.push_back({2,2});
  cout<<"Ban dau: "<<'\n';
  start.print();
  cout<<"**********Luot x **********"<<'\n';
  for(ll i=0;i<4;i++){
    ll u = chuadien[i].first;
    ll v = chuadien[i].second;
    start.a[u][v]=2;
    start.print();
    cout<<"----"<<'\n';
    q.push(start);
    start.a[u][v]=0;
  }
  cout<<"**********Luot o **********"<<'\n';
  ll demm=0;
  while(demm<4){
    State p =q.front();
    q.pop();
    for(ll i=0;i<4;i++){
        if(i==demm) continue;
        ll u = chuadien[i].first;
        ll v = chuadien[i].second;
        p.a[u][v]=1;
        p.print();
        cout<<"----"<<'\n';
        q.push(p);
        p.a[u][v]=0;
    }
    demm++;
  }
  cout<<"**********Luot x **********"<<'\n';
  demm=0;
  while(demm<12){
    State p =q.front();
    q.pop();
    for(ll i=0;i<4;i++){
        ll u = chuadien[i].first;
        ll v = chuadien[i].second;
        if(p.a[u][v]!=0) continue;
        else p.a[u][v]=2;
        p.print();
        cout<<"----"<<'\n';
        q.push(p);
        p.a[u][v]=0;
    }
    demm++;
  }
  cout<<"**********Luot o **********"<<'\n';
  demm=0;
  while(demm<24){
    State p =q.front();
    q.pop();
    for(ll i=0;i<4;i++){
        ll u = chuadien[i].first;
        ll v = chuadien[i].second;
        if(p.a[u][v]!=0) continue;
        else p.a[u][v]=1;
        p.print();
        cout<<"----"<<'\n';
        q.push(p);
        p.a[u][v]=0;
    }
    demm++;
  }
  return 0;
}
